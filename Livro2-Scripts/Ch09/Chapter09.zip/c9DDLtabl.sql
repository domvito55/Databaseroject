CREATE TABLE bb_ddl_log 
 (operation   VARCHAR2(30),
  obj_owner   VARCHAR2(30),
  obj_name VARCHAR2(30),
  userid  VARCHAR2(30),
  action_dt  DATE); 